defmodule IndexerTest do
  use Explorer.DataCase, async: true

  doctest Indexer
end
