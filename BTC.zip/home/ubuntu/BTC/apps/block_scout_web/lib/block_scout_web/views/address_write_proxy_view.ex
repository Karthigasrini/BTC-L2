defmodule BlockScoutWeb.AddressWriteProxyView do
  use BlockScoutWeb, :view
end
