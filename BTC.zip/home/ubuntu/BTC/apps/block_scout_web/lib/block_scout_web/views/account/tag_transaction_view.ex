defmodule BlockScoutWeb.Account.TagTransactionView do
  use BlockScoutWeb, :view

  alias Explorer.Account.TagTransaction
end
