defmodule BlockScoutWeb.Advertisement.BannersAdView do
  use BlockScoutWeb, :view
end
