defmodule BlockScoutWeb.IconsView do
  use BlockScoutWeb, :view
end
