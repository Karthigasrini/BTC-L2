defmodule BlockScoutWeb.Advertisement.TextAdView do
  use BlockScoutWeb, :view
end
