defmodule BlockScoutWeb.AddressReadProxyView do
  use BlockScoutWeb, :view
end
