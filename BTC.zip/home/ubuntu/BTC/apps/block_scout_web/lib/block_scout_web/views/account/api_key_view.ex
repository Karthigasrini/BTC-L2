defmodule BlockScoutWeb.Account.ApiKeyView do
  use BlockScoutWeb, :view

  alias Explorer.Account.Api.Key
end
