defmodule BlockScoutWeb.TransactionTokenTransferView do
  use BlockScoutWeb, :view

  alias Explorer.Chain
end
