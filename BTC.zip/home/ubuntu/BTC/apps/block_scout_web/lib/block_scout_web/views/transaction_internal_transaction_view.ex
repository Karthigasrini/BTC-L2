defmodule BlockScoutWeb.TransactionInternalTransactionView do
  use BlockScoutWeb, :view
  @dialyzer :no_match
end
