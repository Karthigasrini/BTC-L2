defmodule BlockScoutWeb.VisualizeSol2umlView do
  use BlockScoutWeb, :view
end
