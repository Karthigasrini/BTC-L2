defmodule BlockScoutWeb.InternalServerErrorView do
  use BlockScoutWeb, :view

  @dialyzer :no_match
end
