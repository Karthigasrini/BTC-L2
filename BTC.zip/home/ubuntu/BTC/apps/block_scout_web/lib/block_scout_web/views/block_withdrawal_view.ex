defmodule BlockScoutWeb.BlockWithdrawalView do
  use BlockScoutWeb, :view
end
