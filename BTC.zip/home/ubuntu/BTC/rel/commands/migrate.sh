#!/bin/sh

release_ctl eval --mfa "Explorer.ReleaseTasks.migrate/1" --argv -- "$@"